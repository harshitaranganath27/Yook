import React from 'react'

export default function joinHouse() {
  return (
    <div>
      
    </div>
  )
}
